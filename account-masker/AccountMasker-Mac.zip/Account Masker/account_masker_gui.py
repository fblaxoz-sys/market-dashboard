#!/usr/bin/env -S uv run --managed-python --python 3.13 --script
# /// script
# requires-python = ">=3.13"
# dependencies = ["openpyxl>=3.1"]
# ///
"""
Account Masker — point-and-click window around account_masker.py.

Launch:  uv run --managed-python --python 3.13 account_masker_gui.py
(or double-click "Account Masker.app" in this folder)
"""

import os
import subprocess
import sys
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

sys.path.insert(0, str(Path(__file__).resolve().parent))
import account_masker as am

FILETYPES = [("Excel or CSV", "*.xlsx *.xlsm *.csv"),
             ("Excel", "*.xlsx *.xlsm"), ("CSV", "*.csv")]
SCAN_LABEL = "(Scan entire sheet for account-like numbers)"
ICON_PNG_B64 = "iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAABAKADAAQAAAABAAABAAAAAABn6hpJAAArf0lEQVR4Ae2dCZwUxfX4X/fM7AF7wHIICyws9w0BVA4BEW9F8cCf8hejKGj8axKVoPn8PEhM8o+KJCbRGI0J4hUDiIKCB+cicsl9CgssN7hcyy7LHjPd//d6dnAZZtc5Xvd077zSZa7uqupvVb169epVFYAEISAEhIAQEAJCQAgIASEgBISAEBACQkAICAEhIASEgBAQAkJACAgBISAEhIAQEAJCQAgIASEgBISAEBACQkAICAEhIASEgBAQAkJACAgBISAEhIAQEAJCQAgIASEgBISAEBACQkAICAEhIARsQ0CxTU7ilJGWj41K1TIbKskVWrpPq2wJlXHKiCRrDQGPBxQvnKhMU49SgocmvVFqTcL2TCVxBMCkSWpr74HWugbtNZ/WWde0PqqqNNJ1rTuAomLx1ANFaQK6bs+SklzxEFCwyut6MUZ2AssdX/R8BZTj4FJX67q+R1X0benJJflbJk2v4EnQ3rHUaQHQesKYXJ/b0wcLeTAW+gAs+85Y6BngclHB+//XNH8JUbuXxm/v2sqVO6r1JAjoRSXZT2/wM9UFTaOGn49/q0BX8hQXrNyX3Ho7TJpUVVHo4roT6pwAaP30mFxvpftqBbRbFUXpD6qaEShcXaNGLz183am+JjwJtgiFFEJXlWDweit0UNYrOnyquWHOwaQ2G+uSMKgTAqDbqFFJRe1SbwDdNQZb+JWKy5VO3bvuQ6EtDd6EVpJYUSokDEhT8PoqsftYrYIyTatQpx/401s4jHB2cLQAaPnY/VmKx3sfiuy7UJfrS0M6afTOrpC2zj1pByoOH1V84/XtwbzOwv7l9QMvTd1p63zXkjlHCoBzDR+U/wtuVy6N3YyGX8uDyk9CgJUAagSkGehe3ykUCNPAp//NiYLAWQJg/HhPq8yKMaDC02jIyzUafcCIx1q6EpkQCJMAGg8VN2oFPu0Ujjr/rleqk500NHCMAMh+8u6BKrh/i1bb4YDGPJzGC7OE5DIhYAGBKkGg+3w7UC94Zt8Lb//XglRjTsL2AqDxxLHpqeD7NY7zH0dVKxlVrpgfWiIQAmYRMKYV0UaAHdQMl0+buHfyO2QrsG2gCXHbhlaPjenncSkzUd2/A9V9N6pZts2rZEwIGARo1gk1VMXt7qoryh0ZA3oePv3Nhk12pWNbDaDlhDHjcD52Ms3jo1plV36SLyFQIwHSBlAc6KgPvFJWUvpM4WvTS2q8OE4/2E4A5Dw1uqGmeV7Cxn+/Mc6Xefw4VQ1JloUAtjDUBmhIkKdW6A/v+9PbW1jiZYrEVgIg9xd3XVSZ5Hlf8Xiu0CtkVQ5TGUs0NiCgeFAIeLX9iuK7df+L73xrgywZWbCNDaDF43f30pKS5uHcaj+90msXPpIPIcBDAGetFFXJxH/uzOjfff/p5RttYRewhQCgxo+GvjkIKFes/Dz1TWKxHwFcbYiZUpLRrnVjRv8ee+wgBOIuAFr8cnRvcLvn4MKdVmLss1+llRwxE/DbtFyo6dpCCMRVALT4FTZ+l2e2NH7mSibROYGALYRA3IyA2U/c1VhRPCtQErYTtd8J9VXyyE4AHYawAVb4vNqVh//07lL2+MOIsGrRcxhXMl5CU32K4v5QGj8jVInKeQTIpR2UJNXtetewg8XhCawXAPjEuGHHZGOqT9x641DkkqStCPhnB3JwduBt6hitzpvb6gSzJ9x9v+pSx+rlMs9vNXtJz54E9EofoJ9AL9x7aDKqBA/guICmCywJlhoBs395dx9U+z9At6hk2anHkvKVRJxCADUBHAr8JO2LHgeKl29ca1W2LTMCNpn0cFpS8emluF1XbzH6WVW8ko6jCNBOQwDF6AY38OjkdzZbkXfLbACeoqL/RZ9oafxWlKqk4UwCtIpQVdPdPv2v3SaNSrLiISwRAC0n3nMJjvsf173i4mtFoUoaziVA2rGS5L686HTKQ1Y8hfk2ANzGK91VMQ1V/3a4b5oVzyRpCAFnE/B7C/ZJG9h9esnyTUVmPozpGkB2/dK7cc+0y2Xcb2YxStx1ioCxoYjrIpemPmP2c5lqBMz52eiGvhRlAy5+aGWcumL200j8QqAuEVBV3O5aG3RwynsrzHosUzUAX6p6H85vSuM3q/Qk3jpNAFfHkrPwk2Y+pGkaAHk1+crV9biFdw7tkSZBCAiBKAioeJaxrg82SwswzRPQVw734qEdObK5RxSFLrcIgSoCOC3oxjZEWsAtZkAxZQjQ/tHrknVd+ans3W9GkUmciUTAMJ4r6lVNf/XTdmY8tykCoNTT6Bp0+e0l23ibUWQSZ0IRwNEzzqLVd1d4f2bGc/MLAHRmQos/HthJ2aWxv/wJA6kDsdSBqp2yRpmxWpBdADSfMDoHW/1Vsr0XCUAJQoCBAC0Z9qg5lRX6FQyxnRcFuwAAr34t+vzXt25B43nPIx+EQJ0loPiUW7kfjlcAoOVP0TGT5MooWp8wkDrAVgfwTAFq+8Ozx9/VmFMIsAqA5o/8H9zZRB8o6j9nEUlcQgAJYKeK62ku0pOVIZw8WAUAeKCv4nKnifrPWUQSlxCoIoB+gaoL7CsAFB2G4hHeUl5CQAiYQMB/ViYMhEmT2Bz42CKiTCkntw/QNTrJlwZ/EoSAEGAlgG0LW1aX7JO7sw8B7OOIm00ANC/c0UJ3KV0M5x9p/xxlI3EIgfMJYLtCO0Capnv74Q8sAoDNBoDrljrhsl8Z/59fZPJJCPASoCG2D37CFSmbAADV1xndf7nyJfEIASEQigDNBih6t1A/RfMdX4vVld6y1Xc0RSD3CIHwCVQtsOvU/tFHk8O/q+YruQQACiVoWnMy8osQEAKMBBocLy9P4YiPxQiYPX5EqgZaVxybGA4LHBmTOISAEAhBwL+xbvPU5NNtTwKsC3FFRF+xaADqyWM0MBEHgIjQy8VCIGoC2NZ4jtZjEQAV2W0ycIJSFgBFXZ5yoxCIgADNBKgqy5oAFgHgUitaYfabiBEwgkKUS4VAlATQFwBAc3WJ8vbzbmMRAOBTxfXnPKzyQQiYTUA3lgfGmgqPAIg1F3K/EBACcSHAMgtg2CPMP2QsLoAkUSFgOwKM+jaPADAIMebKdsQlQ0LATgT42poMAexUrpIXIWAxAREAFgOX5ISAnQiIALBTaUhehIDFBPhsAHzDEosRSHJCwGEEqK2R2z1DEA2AAaJEIQScSoBPA5BtwJxaByTfjiPAp26LBuC4wpcMCwE+AiIA+FhKTELAcQTYhgB0GJAEISAELCCAbY2ruYkGYEF5SRJCwK4ERADYtWQkX0LAAgJsQwA+pcSCp5YkhICjCdAAgGU1MIgG4OiKIJkXArEREAEQGz+5Wwg4mgDfEIDLLMmMU5fpCWaiiRWdLfe6ZWxrfALAJvWCGnylz4dHFPqdpeslp4Abz1TW2SZObPKgkg1TCdAW19R3lJSfxVcdD71WweN242vd2vy6zggAn6ZBhbcS0lJSoXeb9nBp+87QsXlLaN8s2/hOE03A1AZT1yKnZk51asfhg7D32FFYlb8d1u7ZCceKi8CNm3J6XHWj6Tj+Kahhl1dWQJsmzeDOgcPg6p59oVN2K6jnSTb6fK+ORypL469r7dOS5yEh0L1VLlrKFajUvFBQ+D0s3b4R3v96IawryAcXnoVJ2qWTA6MAYByYhEm0wuuF1KRkePSaUTB22HXQPLORUVBeHAKUVpaHGYtcJgRqJkDDyUBo3bgpdBh6LYzqPxQ++XYZvDj7QzhwvBBSkpICl1j0ytfW+AQAX57Cgni2ogJ65OTCH0ePgwEdukKFrxIbfVlY98pFQiAaAl60K9EfDQHuHnQlDOrUHZ7771T4dM0KSPZ4rDsci9oajxuAM/0ASsvLYeTFg2DG489B/w5d4Cz29jRekyAErCBAQ0rSMFtmNYE3xj8OT428yzA8O3GoyacBWEEe0yjD8f4tl14Gf7n3EUPq0mcJQiAeBCp9XmNWYMKIO9Ae4IIXPv4AXCpaDBw0U+AoR6DyykoY2LGb0fiT3B6gsb4EIRBPAoYRGmefnrj+dhg3/AagoamTgmMEAKn4TTIawIt3P2gYXQLz/E6CLXmtmwRI9S9DIfDkzXfCoM7dcFaK5+ReK2jxCAB8YIJg5h/19hNv+h/omp0DlWj9lyAE7ERAw6P66qekwG9G3QvpqfUMm5SZ7YHLCsgjAEwuCZKoZOwbfdkVcNbrLBXLZDQSvY0IUD29OLcjjBlyJZQ5ZCjgCAFAhpUHr7oRaNxPUlWCELArgXJ0GLp36DXQrGFD0BwwM2V7AUCqfzt05x3SpSeU4zhLghCwMwGqr22bNoehXXphfbX/UNX2AoA8sS7v2hsyU9Ok97dzzZe8nSNAOuq1vS7GKUH7LxziEwD01Cb8uVH9H9atNzo+iaPPuRomb2xNoAL9A/q172TMWhnDABPaBVdz4BMAJhQJwWtYPw06ZreUOX8T+EqU5hCgetsUp6zbNmlu+3rLKAD4xRxNrdDcf2a9+iDLec2prBKrOQRouXAOLh6iOmyKasyUbUYBwJSjatH4EF7zBlnGvKpY/6uBkbe2J+BSXNC6aTPbzwTYWgBQKVPPL43f9vVdMhiCgBOmAR23GCgEZ/mqDhKgBTVm29CNQWuC+5XwCQCiyR3E8M9N1DHxncUl3/71HmaJAd3Y44+cy0wNAdMYZyKMbY1PAHA+oMSV0ARoae3EN/8CSzasNZZ8mwHjbEU5jL/+Fpg46h50L0/c3aMYBQCjWDpX4maIz3ORyxsbEyg8dRL2fX8EUjzmbLd1prwMTp0pMXntfqD+crcNio9nKTyjALBxbZKsOY6Aig5gtPUWaQNmBIq7rm3xHQ0n288CRPNQco8QEALhEWDRAGiJjsqt5WCcZKBNcCNteKUoV0VFwPTp5ar6y16H0TjOZR9nEQBR0ZebhEAtBKhxkhed35Oulgtr/EmpVcWn/irZJPtCjVmy4Q8iAGxYKJIlgHq4u05m/XRIjmaarmrmsOSs/1ivYJ4kXOrjkXGX9+4LdHBMIgdGAWDCGODc8kJri4jqjwt9uWklIv0XCHjioLG4w8otyMkhxjCGoWspnVATCN6qvFjpbRbIixvzEnDToTMXyWXbiyvguNZr+HAJ+OTxvzBOfIJqzxx49h97JaGxZNNa+Nmf/whkTAwOtKVc/649oF+nrridt9lr9qldcLcNvvgYBUAwZud9JqtwsjsJN3KogO/2F8DOg/sh/9B+o7Kn4AlEPXLbQfsWrSAb94Mn1ZTOIjQrUMVNdnmgtKIMNu8rgB0H9sHeo4eNaas03HOue5t20LFlK2iamWX0Ymbuk0g7MiVhXorLSmHLnl2wHdkcOn4M26YCWenp0K11W8xLa8hKyzh3MlOsXLIyMqNo+pSqAimY17yN64zNOVOTky/ICgms24dcgcfHpeCZEol9mAyfAOATSj8UmBnC84fYz3tHJ7sUl5bC+wu+gP8s/hI27s6H4rOlRs9GlQrrurElWfOsxjC0509g7HU3Yw/SBai34tYIaO77+OkieHPRlzADz6HbWrAHSvGUWv826P6xbRLmt1WTi+CKn1wM9187Arrntjc2S41+zHweDuMD6Rs0Tj584hi889U8mL18CXyHgqi6l56Km17QNbnNmsM1/QbAfdeMgA4oJGn3pliMbNFqNi48q2/X0YPwxbcrgBgFByqrFo2awLUXD4QKzTwBfi5dM+owxck0cuETAOee2FlvqJKn4EGiC9d/C79+62+wqWAXGo+wx8OjoEko0F/1cOTkcZg2fy7M/HoRjBoyHJ6/7yFomJaO2kDsqiSp2KS+fvzNEnju7X8YGgip/7S0lBpZ8vlZMRxl3vjsI/gQBda9V98I/zt6LKQkJ1UJiuq5jvw9aUNuTPftLz+D//fBVNhXeMTIB+Un+Cw8qo+7Dh2EP8/8AN6dPw8evul2eOy20bgjjqvKnTfy9KO9IwnzPHfVMjiMGkqo3r8CN+68ul9/yEHhKYfKACS0AAg0/tfmzIBnscGV406udNhobYHU4XpoQKIeauqXn8KGXTth6sRncWiQUzVmre3umn+jxk8N/Xfv/wtenv4uxq8b6dR8BxYeNkb6o9OR/zLrP7Au/zv414Rn4aKsrJi2Tvc7yCgw4R+vwD/nfmyMo+mZawrEMZAX0pqef/ctWL9rB7z+i6cgrV49FoFUU9rVvyeGZ3DI9NHSRcbJvdV/o/ckqEh43Y6Cm31qLjgxh3y+0ELikIxzZDMVx4CvYw/61D//ZlTSUCpjTelQZaNGsWH3DrjrD08b43MPag3RBrI9/PE/U43eVkENJJK4SGNJxbzkbVoHY154Fk6ePh31sdXUmKnnfvKff4XX58w08kGNO9xAApJ63k++yYMHpvzeEKqhDHHhxhfJddT7r/5uK6zb9R3mO0hdwogqcVjSq11HuASNf3SYrAT030lUCLQKLG/LOvjNtDexh1OMM92iYUHGQRqjT3zjL1BeXhGVbzmp97NX5MHk6e8ZQ4BoXVRJIH2zZaOhzVAPR4050kB5mfbVZ0bPTw2ZBF00gQ7J+GzlMnjhw3eiFkaRpkuCc0beAiijcghxs8+nwa2Dh0Facr2Y7BMhonbsV4wCgBQss/54+VKlprHgb7Hxny4tMXq8WFKgOes5K5bCjKULIMVd+xAiOB1q7EVnig1BRFNpsfaW9VNS0WA3F+avW2XYDYLTq+0z9fwHjn0Pf3j/3waTaBt/IA0SIK/Nng5rdm4zDKiB7814Jc1j/7Ej8KVh/LtQEyPjX7OsRnDDpYOsMf4ZD2lWe6B4eQKPACBtyv7Peo4Yqdtf4JnuK7dvxjFhZA32XCRBb0jl/Mdns6CotLhWD7Sg24xpx+l5C2H7vgLWRkINj06qCdUTBuch8JlU6Klo9Dt4rNAY0we+j/aVhBvNGPx99sxoowj7Ppqm/Hz1ckOAkSALDiTwh/e5GHKbZltmk3BCm+ARAMG0bf5Zx3ngmagqerFX4Ao0a7AZ58hXbt+CxrwLx581pUM+Bx8tXRhzz189frJlrNy2Gbbu240N+cLesPq1gffU2xehNjRneV5E9ofA/TW9Jid5jBmWgu8PRz3MqinuwPeUd1rfPxMFqQuHAaECMRmFR3bx9Z2hUnHed6FpOe85ws4xGcyOnjphNFTu3WDIGWfButU1VsLgTJJxbc+RQ7BxTz5ro6MGQW6wi9evBY8angCgGYite3dD/sH9rHkh3oVFJ2HF1s2GM1EwA47PlPe1+dthzY5tIfNO5UJOXAO6dhfjXxDwhBMA1OgKjhyGE8WnWXtd4kpr17ft3WN4EgZxDvnRjarqzgP7oQQdkKI1/IWMGL8kIbAFfRrI6y2cQD3n1n2Yd5xS5A7kEER5MStQ3meiFlWKww167uBADlS3XDYMMlLkdKlgNgknAKihHUHPtrO4I8yFVSUYT2SfaTaBHFDorPhQFTE4NlpncBCNbnSSDHcgYyIZ9HxhLnYh3/593x81/A+480IsaHcfWjfAHcj4d/BEIcxb9Q16/l2o7ZC/RpMGDeHG/pdZaPzjfkrz4ruQWFRpkdvnhYaXqKKqdhP1HPxVxt87YgutlhLjW4w3opgjvT6SrEb4jOEIrUiSr36tWXGT8Y8s/yS8gj0UKX1ySR6Gq/7aN29pvK+eJ7PfG3ZxqsM0J8sZSKtjsl8lnAZAhZGOi2lo3MgdKO4MPMUolBU6VFok3jLr0/X8xUB5aYDHqoU7tKAqSteb1VCNuCMTjaGQnfcdCdoyNKLS3H9N+aZyvmPolTX+fl6ECfiBv+bZHCJZ/mlFH1VIruWrgUemsWaX1m2gHk4thiP1aS16F1xJR1584VwfSCecV1J9acWgWwlP0NHhqz3btkfBaI4m17NtB2z+EelGP/qYNPW6AV2OV6H3H83CBAcy/nVtnQuDutFR3eL5F8yHPiecANA0n+EQ0g2twuQayhmot72se6+wx7rGWfLNsqF9Nv/hp7SIaWD3nmHbAGhdfJecXMhu0tRY4cjFJaAVGWvvNV5bh9/4twhnPEpD9vD0TCMHXQ4N6qWzC1guPvGOJ+EEAKm6yeitd9OAIcaCHq4CoMbcCs+CG9KjT9ibTFDjyExNg+suwaWpDKsJA89CPV/nnDbQr0OXsA2MpDE0a9gIrujdD3tLvoZKPW/fjl2gK+aHc/MNMnIeOXUc5qK7cajpXNLuGuPBsiMGDEbjH9/zBBjXlVc+AUAty6w/Ztrlvgq4DX3CaRMLaiwcoQxXEo658npogZuFRLI/QDkuShlz1fWQ3agxm4caPdMD14/EU5Ujm/aifI/D+zJwBR/H8IhsHKT0P3TjrSEbaSzcabOU+WtX4ZTuoZBei+T5NwT3beiEqzTJxTouwaz2QPEyBT4BYFrrZ3zaKmjU2zVObwCP3T7an2vsLWIJVNlo/DwWN8OgBh1JoOOv2qB76sM3j2KpqCSILuvR29irgLwMIwnUQ9NY/d5rboQy9KyLNdCinBtw+u3qvv1Zx+A0uUG7MU1fsqDGFU8unJIdhca/WNdWxMbA/hKAUQDEhsrqu89Wlhs99ljcTacUfQKiDdS71E9NhSkPPYa2hcZRbYBBDfXnN99hjFfPlJ2NNitGo2jWMAv+9LPHgLYNi6YXJ+3hadxYZGjPPjFxoc02OuCWZS+N+wX20CrrGJws+5sK8mHFtk0hNQsSZJ1atTE0ADO3bYu6oGx0Y8IKACoDMgL+8f5H4Ke4m86ZsjJjn79IyoZ6flp999YTT8Pg7r1xh5noek1jBgB7tVcfnWiMWUkIRDorQD1/0wZZMO2p3xh79EVb8WlLsRRcxffvXz1rWM+jyQstAKJ59/d+/Ty0bNwEx/5M+1dVFY4LNyX96OvFuIXbmdDGPxRiZONpVD8zKiEYSR1w+rUJLQCoh3Rh7/TKw0/AH8Y+jH7kuAknVl4aItQWqJcsRYFB6vInv30Zrr9kEG4uGV3jD6RD42/SJP71xLMw8Y57jK9pgUttvTiNsamhk1cjCaA5z09Bf/eeMW91RQbNJpkN4cOn/wDjbrjFsE2QgKlNKNFvtPqQhg7kdTf7+ZfR8JfLqvoTFFLpvz99Ej7F5dehNv0gXg1xc9KRg4YaG5QG+MpraAIXTp6Gvq7OfksNj6bvHrvtLtxgsx+8/ulM+HzVcmMBC1UmWswSCDRep+XDnVG9vA+HDv9z+VXQIC0t5gYXiJ8aXhKunnvunnFw3aUDcS39DFiEexWewB1+qLH/kBfcihvzXS85FXq362QY7mi6izbh4PLlJzU6HY2BUx76Jdwy8HJjXf8y3GzkFO5dQPP5AccbyhdtX5aOwmsgbrX94I23oUAcaCzKMWPunTz/Fq771tiDMHi/RuJIWtlVfS4xpjQ5Zx0CZVTXXvkEQGx2tNBcAzaU0L+yfUsNncas3dE34LWfP2Vs77Vs8wbYjAtYaGtwquzkZtoLe/y+HTtDX5xeIws7Gfyo1+MMpH1U4N8lnbsZW1ftOnwQlm3CvOzdZSxiIgNYemp9w+hI19AWV2koCMgjLlq1v6b8k5ChQAdoDEbD4o6D+4C4bMJlz4eOFxq/ZWVkQM/cDtC/S3eDH22wSjYNsxof2Vxm5M2vURshYU7GP1poZVYejAcP9x8z6jDFyTSq4hMA4QKx8XWBKcEWjZvC3cOvM3LqQw85CtTr0dEcdDgIzdnHqvIbkdbyD/VkFHLRUahjdo7xPjgv5ElIldzsvAS0io4tc6B7Tjskgr1+FRc6rIQWNVXqXv9QIcahkPGgNfxD+yTSqsJlmzdesFsz3UIaFHl5ksCKdAakhiTr/NeMAsDBKkBQMZOqfxb/7BCoUtOfHUK880InEs1atsQYhoTapZg0IHL8aYJTvGYLxfDLwywVwN8xhZ+P0Ff+MMAN/bt8KwRsQYCMf8eLi2DON3kh/f7JCJmJ6zvIFpLo5/1FUmAiACKhJdfGjQDtV7h441rjiLRQ25xR7z8AjZC0AMqLQzQJ4RFgGwKgAGYPRpwmxMueUYnQdAJkkJy+ZH6t06K05x8JCrsM39BUgsZK/x8rIMY2IRoAa8lIZGYQIM8/OpB0KR58EurwFrJN5DZrAcPxnMRIXbHNyK+T4hQB4KTSStC80pTeR3gWY+GpU9ijav4DWbHR+w9m9RnOR7Tf/0XoCfljTlwJirDGx2YbAviXAtaYTpQ/kK7DqO9EmQu5LX4EyAeDtitfs2M7tG3eAh2Mzt+whFRs2lGJzvsLd/9D654mUH+56zBffIwCwDqsklLiECDrvhsb/VsTnsaHpsXFwcHvIUmnM3HuqRCcSl39zCMAyGflfMHMw4tP0PHkR2KJCwFygaZ9HGsLta2ZqO0+038LKAGcCTG2Cx4BwPlwEpcQCEHAtg08RF6d9JXtjYDk2x1YeOIksJJXIfDD4i37srC1AKDGX4RrvmkpqggB+1YiydmFBGhfBfJctHu9ZRQAgcEO36v/yOfv0fe7xPYgL6wC8k0iEyB35B2H9lct4eZrE/5ZMYqPZ30IowDgL27SAE6VFMNePFbKjVM9EoSAEwjQuoWT5+ptqJkL+zwFX6syQ8ghJ9pY8uutG8I+4MI+aCUniUqADlfZvHcPnvtY6D8lyoy2wbMYEBdy2zzQibtfrVsNpZW4cae9hanNSUr2rCLgwjnxz9esYN8sxoz8214A+KXpbtiwJ9+08+XNACtxJiYBUv8LS07Bwg3fhly2bDcqthcAZEWlTS/f+PyTanvi2Q2j5EcI+AmkupJgBq5bIAOg24RzFrk5214A0AMne5Jg7rffwKJNayAF30sQAnYkQA1+3/Gj8Pq8WaacPm3GMzMJgEpjk0by2zbjjx6cfAGeeedNOIHWVTOO0zYDrsSZWATosNLff/i2sWMx1VEz2kIgTiYboP2NgIEqRAdAbsTTYJ59902Urh7xCwiAkVdbEKjvSYGpC+fBB3lf4XHvybbIUziZYNIAwkkq9mtoy+n3l3wJL3/8Pp7wK0IgdqISAweBetj4565bAZPee8s/7ccRqUVxOGoxENoDjf3ef/fBVMMh6vGRd4IXt4qiXXwlCAGrCZCBOhWPmp+7djk8+NcXoASPdHOC4a86J0dpAJRxgk77w/8Ox1oPvfqS4SmYipqBBCFgJQEakpJbykuz3oOxf/69Ixs/8eLTAMjbyaJAh3TQPnEfLPkK1u3eAb8Z/QBc0/cSFA6qcToOGUokCAFuAkbng5Z+OpyU7FHPocq/oGq+n7Yts2zzKqreTFZAPgFg2dP7i5Wkbyoe15WPR3fdM+W3MLxXPxh/7c3Qr0NnaIDHdtHpNV4cGtAecSIOuJtC4sRH1nzjD737yBt1I55MNG3BPJi5bJGxSO2HaWkraxlfWowCID6VgoYDdEDlvDXLYf761cax1Ff06guD8JRcOlarWcMsw3eArpEgBMInoBidx5GTx+HQiWOw6rut8BXWLzovksb65JvyQ+MPP1a7Xel4AUBAaUgQKIyd6IG1Zd8eeH3uLJyOSYHsrEbGwZ4yKrBb1bN/fmhN/0E8BJWOgqfDY8nAR0PPVDwhuq6EOiEAqhcGFVLAEluJp8XsPnLI0BCqXyPvhUA4BIwDYXEIoOBfqLMIw4nD7tfUOQFQHTgZbQLCoPr38l4ICAE/AT4BIENsqVNCwBoCjG3NcX4A1hCWVIRAYhDg0wDEyp4YNUae0gYESAXgcQQQDcAGxSlZEALxIiACIF7kJV0hYAMCPEMAPBpMN+NoMBsAkiwIAdsRoBEA0/o30QBsV7qSISFgHQERANaxlpSEgO0I8AwBjMdinJy0HSbJkBCwEwG+tiYagJ3KVfIiBCwmwKcB8AklixFIckLAYQQY25poAA4re8muEOAkIAKAk6bEJQQcRkAEgMMKTLIrBDgJ8NkAZC0AZ7lIXEKgFgJkBODxBOITAIyGiVqeXH4SAkKAsa3JEECqkxBIYAIsAkBXfSzxJHA5yKMLgYgI6IB7kzMElobr1lzHQFeKGfIjUQgBIfBjBDQcA+jqgR+7LJzfWQRAamH2YdyY9ziezBFOmnKNEBACMRDQ8awLl67tiiGKc7eyCICK9OMYjywIPkdV3ggBkwngjuUsBnyWSA6lpJQ30Mt2qgq0kmO5TC55iT6xCZCWrUOhWqnt5wDBogHA9Ok+RYfvZQjAUSQShxD4EQKKfrreaV/Rj1wV1s88AsCf1Hq0A0gQAkLARAJ0SAlqAN8VLF5czpEMmwDQVD0f5PwtjjKROIRAzQRoBKAr+XgBizsQnwDwqVt0nw93B5QgBISAaQSo2evaWq74WYyAlJmLSl17jqdp+WgH6AI0TylBCAgBdgK611epqkmruSJm0wDy580rV3R9FZ3H59dODFEl7w1NTVhInWCoA9S0FD0/qwRYfABIiLAJAIpMA2UJvUoQAkKAn4CC8+w427aKOluu2FkFgKroK1FF8XJlTuIRAkKgGgHUrjVdyav2TcxvWQVAbsNTOzGP6wEllQQhIAR4CWDnWgIe90LOWNlbaoNbr3xa9ajPY2Y58ylxCYGEJqC4sK/26V+cmDH/OvS3YbOys2oAVEKKos+WYUBC11V5eDMIoGqNbvazOBs/ZZNdAJzs4duK8mk1GSwkCAEhwEAAm5Lu9Z4ClzKPIbbzomDZVOC8GBcXaPW6tnNhZkcALluUIASEQGwEFDf205r+0ckZC/4dW0wX3s2uAVASXtU1A4cB+2Rx0IXA5RshECkB3ad7cQTwaqT3hXO9KQLg9PQvTuigzzAMF+HkQq4RAkIgNAFa/KNpa04ojVaGviC2b9lcgYOzoYPrVc2rPYBmwQxZJBRMRz4LgfAIoOMPOtipk2nJfXh3RHaVKRoAZaFo5vzd4NPeFi0gsgKRq4VAgAAt/cXtv1YXubJmB77jfjVNAFBGdZfrz7hCsFj2CeAuNokvIQiQ9R+UF7H3rzDreflnAarltHzb7pPJXdqkq251sKwQrAZG3gqBHyFAmrPu1RYXuRs9A1u3mqL+UxZM1QAoAUXTX8QH2SXuwURDghAIj4Cu6eXo9/+kmb0/5cRUDYASKNteUIZawCFVUe8QLYCISBACtRNQ3NgsfdprRR8veqv2K2P/1XQNgLJY5GoyC20BsxSX6fImdiISgxCIJwH0oEWNebfX7f2dFdmwzF+3wcjL24Cq0lxmU5kWtKJoJQ1HEsA19Yqm3XRy1uJPrci/JRoAPcipjxcXqKD9nHsxgxWQJA0hYAWBKtX/FasaPz2TpTr52W0FW1I6t26ID9pf1glYUaUkDacQoOExzvkvS05LGntm4y7LNte1VABQYWTmdFyK45uh+MA5YhR0SvWUfJpKgFbO4sE6Lt13W+GHCw+ZmlZQ5JYNAQLpHv3yyzMu0MbpPjzaSJYMB7DIa6ISwFU+OFlermveR4/PyttmNQbLBQA9ID2origjUeqVyIpBq4tc0rMTAcPd16c9UvRx3n/jkS/LhwCBhyzftudwaqfcvagFjMDv4paPQH7kVQhYTcAY9/u8U4o+WfKC1WkH0otrwyv7rmBTaofWe8Cl3ogZimteAkDkVQhYQcDf+LUpODv2hBXp1ZRG3BudCIGaika+r7MEjA0+fXFv/MQ37gKAMkFCIKlDqz04HLgB/QTc4ihEVCTUOQJk8CNPP02bUvTxkrj2/AG2ZIK0TWgwYvBQ3aW+gx6DrdAX2jb5kowIgZgJGDNeSgXW60eKZi95M+b4mCKwhQYQeJayHfv2prZvuxDPP7oUnYWai59AgIy8OpoAqfy6chR034NFs/Om2elZbCUACEzZjoKjKe1a/henBxujJtDHTrAkL0IgUgLk3ovbeuWpleV3nprz9aJI7zf7elsNAYIfNvOmoeNQCExWVMhAx6Hgn+WzELAvAb+TG57lAa8ke+CZwumLS+yYWVsLAALW4JZhvZDiy3js+HDcJAFVKfyTIATsSgBblDHFp2k7NU2bUDw7z7T9/DgQ2G4IEPxQuKHI0fJmbd5PSfGdxMORe+FWSeloRg2+TD4LgfgTMMb6UI5d1KuaUnFfySdfr41/pmrPge01gOrZzxwxJBenUX6NU4Vj0UbgkpmC6nTkfdwI0N791JI0bYGmKs8Uz1qyPG55iTBhRwmAwLOl3zR4kKqqj+NagptRIODaItQIZGQQwCOvVhGghk9Bh5W4+eWUov1nZsGaNZYt5fUnHtu/jhQAgUdOv2kYCgKNBMHVuKgiDR0sxEYQgCOv5hBAZ56q/fp92HhW6or+SlFTbPhvOKvhB+A4WgAEHiL9lss6qj73eGz9t6JGkEsPJQbDAB15jZkAVSjs7dEQjVP5vpM6qHNxv/6/F89eRKq+ow1SdUIABAo4Y9SALKUyZRhuRT4SZw6uRGHQzCg0mjkI/AUullchUBsBnMZTcP6ZAjb60zjGX45/uLGt+/NTHy3cW9utTvqtTgmA6uDTrhvcxOWGIWgrHKzr2gD8rTMKhAwSCBRogtYvFIyPVf+IIaE6jbr7vlq1r3pLan0gYIOvwHqSr+vKSpQBS1GbXFw0J29P4Pe69FqNRF16rKBnmQRq5pohrbHF91FcSg/dB91RmeuCm5LQwaUt8GoS9zh/i5VAZEAQvDr2EWu8MTwke5E/FOJLMZb+Fk2B3aqur0dZsOpE0ol8mL7FtCO5AonH+zUxBEAoyqO6JTWE5ql6eUVb9DJUweXKwl2LO5l2BlOoPMh3lhNw4QJYTfcdxn8KwAPg1SoPNExWTx+Yvvys5ZmRBIWAEBACQkAICAEhIASEgBAQAkJACAgBISAEhIAQEAJCQAgIASEgBISAEBACQkAICAEhIASEgBAQAkJACAgBISAEhIAQEAJCQAgIASEgBISAEBACQkAICAEhIASEgBAQAkJACAgBISAEhIAQEALVCfx/MMHQxJNJmnIAAAAASUVORK5CYII="


def read_headers(path: Path) -> list[str]:
    """First-row values, for the column dropdown."""
    if path.suffix.lower() == ".csv":
        import csv
        with open(path, newline="") as f:
            row = next(csv.reader(f), [])
        return [h for h in row if h.strip()]
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True)
    ws = wb.worksheets[0]
    row = next(ws.iter_rows(min_row=1, max_row=1, values_only=True), ())
    wb.close()
    return [str(h) for h in row if h is not None and str(h).strip()]


def guess_account_header(headers: list[str]) -> str | None:
    for h in headers:
        if "account" in h.lower() or "acct" in h.lower():
            return h
    return None


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        root.title("Account Masker")
        root.geometry("560x460")
        root.minsize(480, 380)
        try:
            self._icon = tk.PhotoImage(data=ICON_PNG_B64)
            root.iconphoto(True, self._icon)
        except Exception:
            pass  # cosmetic only — never block launch over an icon

        outer = ttk.Frame(root, padding=16)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text="Account Masker",
                  font=("Helvetica", 20, "bold")).pack(anchor="w")
        ttk.Label(outer, foreground="gray",
                  text="Mask before uploading to an unsecured system. "
                       "Unmask after you take the file back out.").pack(anchor="w", pady=(0, 12))

        btns = ttk.Frame(outer)
        btns.pack(fill="x", pady=(0, 12))
        mask_btn = tk.Button(btns, text="Mask a file…", font=("Helvetica", 14),
                             height=2, command=self.do_mask)
        unmask_btn = tk.Button(btns, text="Unmask a file…", font=("Helvetica", 14),
                               height=2, command=self.do_unmask)
        mask_btn.pack(side="left", expand=True, fill="x", padx=(0, 6))
        unmask_btn.pack(side="left", expand=True, fill="x", padx=(6, 0))

        self.log = tk.Text(outer, height=10, wrap="word", state="disabled",
                           relief="solid", borderwidth=1, padx=8, pady=8)
        self.log.pack(fill="both", expand=True)

        self.status = ttk.Label(outer, foreground="gray")
        self.status.pack(anchor="w", pady=(8, 0))
        self.refresh_status()
        self.say("Ready. Pick a file to mask or unmask — the file itself is "
                 "updated, so there's just one copy to keep track of.")

    # ------------------------------------------------------------- helpers

    def say(self, text: str):
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def refresh_status(self):
        try:
            vault = am.load_vault(am.DEFAULT_VAULT, allow_fresh=True)
            n = len(vault["map"])
            am.backup_vault(am.DEFAULT_VAULT)
        except SystemExit:
            n = "?"
        nb = len(am.vault_backups(am.DEFAULT_VAULT))
        self.status.configure(
            text=f"Vault: {am.DEFAULT_VAULT.name} — {n} account number(s) stored, "
                 f"{nb} automatic backup(s) in Documents. Keep both private.")

    def ensure_vault(self) -> bool:
        """If the vault file vanished but backups exist, offer to restore it.
        Returns False only when the user declines a needed restore."""
        if am.DEFAULT_VAULT.exists():
            return True
        backups = am.vault_backups(am.DEFAULT_VAULT)
        if not backups:
            return True                    # genuinely fresh start
        newest = backups[-1]
        if messagebox.askyesno(
                "Account Masker",
                f"The vault file is missing, but an automatic backup exists "
                f"({newest.name}).\n\nRestore it now? (Without it, previously "
                f"masked files cannot be unmasked.)"):
            am.restore_latest_backup(am.DEFAULT_VAULT)
            self.say(f"Vault restored from backup: {newest.name}")
            self.refresh_status()
            return True
        return False

    def pick_file(self, title: str) -> Path | None:
        p = filedialog.askopenfilename(title=title, filetypes=FILETYPES)
        return Path(p) if p else None

    def ask_column(self, headers: list[str]) -> str | None | bool:
        """Returns header name, None for scan mode, or False if cancelled."""
        dlg = tk.Toplevel(self.root)
        dlg.title("Which column holds the account numbers?")
        dlg.transient(self.root)
        dlg.grab_set()
        frame = ttk.Frame(dlg, padding=16)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="Which column holds the account numbers?").pack(anchor="w")

        options = headers + [SCAN_LABEL]
        guess = guess_account_header(headers)
        var = tk.StringVar(value=guess if guess else (headers[0] if headers else SCAN_LABEL))
        combo = ttk.Combobox(frame, textvariable=var, values=options,
                             state="readonly", width=42)
        combo.pack(pady=10)

        result: list = [False]

        def ok():
            result[0] = None if var.get() == SCAN_LABEL else var.get()
            dlg.destroy()

        row = ttk.Frame(frame)
        row.pack()
        ttk.Button(row, text="Cancel", command=dlg.destroy).pack(side="left", padx=6)
        ttk.Button(row, text="Mask it", command=ok).pack(side="left", padx=6)
        dlg.wait_window()
        return result[0]

    def process_in_place(self, path: Path, transform, column):
        """Rewrite the file itself (via am's atomic temp-swap). Caller is
        responsible for saving the vault BEFORE calling finish()."""
        changed, tmp = am.process_file(path, path, transform, column)
        return changed, tmp

    def reveal(self, path: Path):
        """Show the finished file in Finder / File Explorer."""
        try:
            if sys.platform == "darwin":
                subprocess.run(["open", "-R", str(path)])
            elif sys.platform == "win32":
                subprocess.run(["explorer", f"/select,{path}"])
            else:
                subprocess.run(["xdg-open", str(path.parent)])
        except Exception:
            pass  # revealing is a courtesy; never let it break the run

    # ------------------------------------------------------------- actions

    def do_mask(self):
        if not self.ensure_vault():
            return
        path = self.pick_file("Choose the file to MASK")
        if not path:
            return
        try:
            headers = read_headers(path)
        except Exception as e:
            messagebox.showerror("Account Masker", f"Couldn't read {path.name}:\n{e}")
            return
        column = self.ask_column(headers) if headers else None
        if column is False:
            return
        try:
            vault = am.load_vault(am.DEFAULT_VAULT)
            masker = am.Masker(vault, column_mode=column is not None)
            changed, tmp = self.process_in_place(path, masker.mask_text, column)
            # Vault first: never overwrite real numbers before the mapping is safe.
            am.save_vault(am.DEFAULT_VAULT, vault)
            if tmp is not None:
                tmp.replace(path)
        except SystemExit as e:
            messagebox.showerror("Account Masker", str(e))
            return
        except Exception as e:
            messagebox.showerror("Account Masker", f"Something went wrong:\n{e}")
            return
        msg = (f"MASKED {path.name} — updated in place\n"
               f"   • {changed} cell(s) masked "
               f"({masker.new} new, {masker.reused} seen before)")
        if masker.swept:
            msg += (f"\n   • safety sweep caught {masker.swept} extra "
                    f"occurrence(s) outside the chosen column")
        if am.LAST_FORMULA_HITS:
            msg += (f"\n   ⚠️ {am.LAST_FORMULA_HITS} formula cell(s) may mention "
                    f"account-like numbers. Formulas are never modified — "
                    f"review them before uploading.")
        msg += ("\n   ✅ This same file is now safe to upload. Unmask it here "
                "when you take it back out.")
        self.say(msg)
        self.refresh_status()
        self.reveal(path)

    def do_unmask(self):
        if not self.ensure_vault():
            return
        path = self.pick_file("Choose the file to UNMASK")
        if not path:
            return
        try:
            vault = am.load_vault(am.DEFAULT_VAULT)
            if not vault["map"]:
                messagebox.showerror("Account Masker",
                                     "The vault is empty — mask something first.")
                return
            um = am.Unmasker(vault)
            transform = lambda text, _whole: um.unmask_text(text)
            changed, tmp = self.process_in_place(path, transform, None)
            if tmp is not None:
                tmp.replace(path)
        except SystemExit as e:
            messagebox.showerror("Account Masker", str(e))
            return
        except Exception as e:
            messagebox.showerror("Account Masker", f"Something went wrong:\n{e}")
            return
        msg = (f"UNMASKED {path.name} — updated in place\n"
               f"   • {um.restored} token(s) restored to real account numbers")
        if um.unknown:
            msg += (f"\n   ⚠️ {len(um.unknown)} token(s) not in the vault were left "
                    f"as-is: {', '.join(sorted(um.unknown)[:8])}")
        self.say(msg)
        self.reveal(path)


def main():
    root = tk.Tk()
    App(root)
    if os.environ.get("ACCOUNT_MASKER_SELFTEST"):
        root.after(1500, root.destroy)
    root.lift()
    root.attributes("-topmost", True)
    root.after(400, lambda: root.attributes("-topmost", False))
    root.mainloop()


if __name__ == "__main__":
    main()
