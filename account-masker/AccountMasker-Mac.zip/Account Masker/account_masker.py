#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.10"
# dependencies = []
# ///
"""
account_masker.py — tokenize account numbers before they enter an
unsecured system, and restore them afterward.

  MASK:    real account numbers  ->  fake tokens like ACCT-7F3K92
  UNMASK:  fake tokens           ->  real account numbers

Excel files are edited surgically: only the individual cells being
masked or unmasked are rewritten. Everything else in the workbook —
formulas, tables, defined names, external links and their cached
values, charts, styles, macros — is copied through byte-for-byte, so
the file keeps working in Excel after the round trip. Unmasking also
restores plain account numbers as real numeric cells (not text), so
lookups like MATCH/VLOOKUP against them keep working.

The real<->fake mapping lives in a local vault file (account_vault.json,
kept next to this script by default). The same real number always gets
the same token, so masked data stays consistent across files and runs.

KEEP THE VAULT FILE PRIVATE. Never upload it anywhere. Without it,
masked files cannot be reverted.

Usage:
  uv run account_masker.py mask   accounts.xlsx
  uv run account_masker.py mask   accounts.xlsx --column "Account Number"
  uv run account_masker.py unmask accounts_masked.xlsx
  uv run account_masker.py list
"""

import argparse
import csv
import datetime
import html
import json
import re
import secrets
import sys
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_VAULT = SCRIPT_DIR / "account_vault.json"

# Vault backups live OUTSIDE the tool folder on purpose: deleting or
# replacing the folder (it happens) then can't take the backups with it.
BACKUP_DIR = Path.home() / "Documents" / "Account Masker Vault Backups"
BACKUP_KEEP = 20

# Token alphabet skips ambiguous characters (0/O, 1/I/L).
TOKEN_ALPHABET = "23456789ABCDEFGHJKMNPQRSTUVWXYZ"
TOKEN_LENGTH = 6
# ACCT- tokens replace account numbers, NAME- tokens replace client names.
TOKEN_RE = re.compile(r"(?:ACCT|NAME)-[" + TOKEN_ALPHABET + r"]{" + str(TOKEN_LENGTH) + r"}")

# What counts as an account number when scanning without --column:
# 6+ digits, optionally broken up by dashes, spaces, or dots.
ACCOUNT_RE = re.compile(r"(?<![\dA-Z])(?:\d[\s\-.]?){5,}\d(?![\dA-Z])", re.IGNORECASE)

# Set by process_xlsx: formula cells that looked like they mention account
# numbers or tokens (formulas are never modified, only counted).
LAST_FORMULA_HITS = 0


# ---------------------------------------------------------------- vault

def vault_backups(path: Path) -> list[Path]:
    """Existing backups of this vault, oldest first."""
    if not BACKUP_DIR.is_dir():
        return []
    return sorted(BACKUP_DIR.glob(f"{path.stem} *.json"))


def load_vault(path: Path, allow_fresh: bool = False) -> dict:
    if path.exists():
        with open(path) as f:
            vault = json.load(f)
        if "map" not in vault:
            sys.exit(f"ERROR: {path} does not look like a vault file.")
        return vault
    backups = vault_backups(path)
    if backups and not allow_fresh:
        sys.exit(f"ERROR: vault {path} is missing, but a backup exists:\n"
                 f"  {backups[-1]}\n"
                 f"Restore it with:  uv run account_masker.py restore-vault\n"
                 f"(or pass --vault to use a different vault on purpose)")
    return {"created": datetime.datetime.now().isoformat(timespec="seconds"),
            "map": {}}  # real -> token


def save_vault(path: Path, vault: dict) -> None:
    vault["updated"] = datetime.datetime.now().isoformat(timespec="seconds")
    tmp = path.with_suffix(".json.tmp")
    with open(tmp, "w") as f:
        json.dump(vault, f, indent=2)
    tmp.replace(path)
    backup_vault(path)


def backup_vault(path: Path) -> Path | None:
    """Snapshot the vault into BACKUP_DIR (skipping if nothing changed
    since the newest backup). Keeps the newest BACKUP_KEEP snapshots."""
    if not path.exists():
        return None
    data = path.read_bytes()
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    backups = vault_backups(path)
    if backups and backups[-1].read_bytes() == data:
        return backups[-1]
    stamp = datetime.datetime.now().strftime("%Y-%m-%d %H.%M.%S")
    dest = BACKUP_DIR / f"{path.stem} {stamp}.json"
    dest.write_bytes(data)
    for old in backups[:-(BACKUP_KEEP - 1)] if len(backups) >= BACKUP_KEEP else []:
        old.unlink()
    return dest


def restore_latest_backup(path: Path) -> Path:
    """Copy the newest backup back to `path`. Returns the backup used."""
    backups = vault_backups(path)
    if not backups:
        sys.exit(f"ERROR: no backups of {path.name} found in {BACKUP_DIR}.")
    if path.exists():
        # Don't clobber a live vault: keep a snapshot of it first.
        backup_vault(path)
    path.write_bytes(backups[-1].read_bytes())
    return backups[-1]


def new_token(existing: set, prefix: str = "ACCT") -> str:
    while True:
        tok = prefix + "-" + "".join(secrets.choice(TOKEN_ALPHABET) for _ in range(TOKEN_LENGTH))
        if tok not in existing:
            return tok


# ------------------------------------------------------------ transforms

class Masker:
    def __init__(self, vault: dict, column_mode: bool = False,
                 sweep_names: bool = False):
        self.map = vault["map"]                       # real -> token
        self.tokens = set(self.map.values())
        self.column_mode = column_mode
        # Only sweep client names out of other cells when THIS run is
        # masking names — a run without --names-column means names are
        # meant to stay visible, even if the vault knows some.
        self.sweep_names = sweep_names
        self.new = 0
        self.reused = 0
        self.swept = 0
        self._sweep_re = None  # built lazily; invalidated when the map grows

    def token_for(self, real: str, prefix: str = "ACCT") -> str:
        tok = self.map.get(real)
        if tok:
            self.reused += 1
            return tok
        tok = new_token(self.tokens, prefix)
        self.map[real] = tok
        self.tokens.add(tok)
        self.new += 1
        self._sweep_re = None
        return tok

    def mask_name(self, text: str, whole_cell: bool) -> str | None:
        """Names column: replace the whole cell with a NAME- token."""
        if TOKEN_RE.search(text) or not text.strip():
            return None
        return self.token_for(text.strip(), "NAME")

    def mask_text(self, text: str, whole_cell: bool) -> str | None:
        """Return masked text, or None if nothing to mask."""
        if TOKEN_RE.search(text):
            return None                               # already masked
        if whole_cell:
            return self.token_for(text.strip())
        if not ACCOUNT_RE.search(text):
            return None
        return ACCOUNT_RE.sub(lambda m: self.token_for(m.group(0)), text)

    def sweep_text(self, text: str, _whole: bool = False) -> str | None:
        """Column mode: replace known account numbers leaking into OTHER cells
        (e.g. an account number repeated inside a notes column)."""
        if not self.map:
            return None
        if self._sweep_re is None:
            # One combined pattern for all known numbers (longest first so
            # e.g. "12345678" wins over "123456") — scales to many thousands.
            vals = sorted((v for v in self.map
                           if v.isdigit() or self.sweep_names),
                          key=len, reverse=True)
            if not vals:
                return None
            self._sweep_re = re.compile(
                r"(?<![\dA-Za-z])(?:" + "|".join(re.escape(v) for v in vals) + r")(?![\dA-Za-z])")
        text, n = self._sweep_re.subn(lambda m: self.map[m.group(0)], text)
        if n:
            self.swept += n
            return text
        return None


class Unmasker:
    def __init__(self, vault: dict):
        self.reverse = {tok: real for real, tok in vault["map"].items()}
        self.restored = 0
        self.unknown = set()

    def unmask_text(self, text: str) -> str | None:
        if not TOKEN_RE.search(text):
            return None

        def repl(m):
            real = self.reverse.get(m.group(0))
            if real is None:
                self.unknown.add(m.group(0))
                return m.group(0)
            self.restored += 1
            return real

        return TOKEN_RE.sub(repl, text)


class Checker:
    """Read-only 'is this file safe to upload?' scan. Never modifies cells."""

    def __init__(self, vault: dict):
        digit_keys = {k for k in vault["map"] if k.isdigit()}
        name_keys = [k for k in vault["map"] if not k.isdigit()]
        self._digits = digit_keys
        self._name_re = (re.compile(
            r"(?<![A-Za-z])(?:" + "|".join(re.escape(n) for n in
                                           sorted(name_keys, key=len, reverse=True)) + r")(?![A-Za-z])")
            if name_keys else None)
        self.reals = 0        # vault account numbers still visible
        self.names = 0        # vault client names still visible
        self.acct_like = 0    # other account-looking numbers (not in vault)
        self.tokens = 0       # masked tokens present
        self.formula_hits = 0

    def check_text(self, text: str, _whole: bool):
        self.tokens += len(TOKEN_RE.findall(text))
        scrub = TOKEN_RE.sub(" ", text)
        for m in ACCOUNT_RE.findall(scrub):
            if re.sub(r"\D", "", m) in self._digits:
                self.reals += 1
            else:
                self.acct_like += 1
        if self._name_re:
            self.names += len(self._name_re.findall(scrub))
        return None           # read-only: never rewrite the cell


def check_file(path: Path, vault: dict, sheet=None) -> Checker:
    """Scan a file without changing it; returns the populated Checker."""
    global LAST_FORMULA_HITS
    LAST_FORMULA_HITS = 0
    ck = Checker(vault)
    tmpout = path.with_name("." + path.name + ".checktmp")
    try:
        process_file(path, tmpout, {"scan": ck.check_text}, sheet)
    finally:
        if tmpout.exists():
            tmpout.unlink()
    ck.formula_hits = LAST_FORMULA_HITS
    return ck


# ------------------------------------------------- xlsx surgical editing
#
# The workbook is treated as the zip archive it is. Only the <c> cell
# elements that actually change are rewritten inside each sheet's XML;
# every other byte of every part is copied through unchanged.

CELL_RE = re.compile(r"<c\b[^>]*/>|<c\b[^>]*>.*?</c>", re.S)
CELL_REF_RE = re.compile(r'\br="([A-Z]+)(\d+)"')
T_ATTR_RE = re.compile(r'\s*\bt="[^"]*"')
V_RE = re.compile(r"<v[^>]*>(.*?)</v>", re.S)
T_TAG_RE = re.compile(r"<t(?:\s[^>]*)?>(.*?)</t>", re.S)
F_TAG_RE = re.compile(r"<f[\s>/]")
F_CONTENT_RE = re.compile(r"<f[^>]*>(.*?)</f>", re.S)
RPH_RE = re.compile(r"<rPh\b.*?</rPh>", re.S)
SI_RE = re.compile(r"<si\b[^>]*/>|<si\b[^>]*>.*?</si>", re.S)


def parse_shared_strings(data: bytes) -> list[str]:
    """Flatten each <si> entry (including rich-text runs) to plain text."""
    out = []
    for si in SI_RE.findall(data.decode("utf-8")):
        si = RPH_RE.sub("", si)  # drop phonetic runs
        out.append("".join(html.unescape(t) for t in T_TAG_RE.findall(si)))
    return out


def numeric_cell_text(raw: str) -> str | None:
    """Text of a numeric cell if it displays as a whole number, else None.
    Floats (prices, date/time serials) are never treated as account numbers."""
    try:
        f = float(raw)
    except ValueError:
        return None
    if f.is_integer() and abs(f) < 1e15:
        return str(int(f))
    return None


def cell_text(cell: str, t: str, shared: list[str]) -> str | None:
    """The value a human sees in the cell, or None if not maskable."""
    if t == "s":
        m = V_RE.search(cell)
        try:
            return shared[int(m.group(1).strip())] if m else None
        except (ValueError, IndexError):
            return None
    if t == "inlineStr":
        return "".join(html.unescape(x) for x in T_TAG_RE.findall(cell))
    if t in ("b", "e", "str"):
        return None                       # booleans, errors, formula results
    m = V_RE.search(cell)                 # plain numeric cell
    return numeric_cell_text(m.group(1)) if m else None


def rebuild_cell(cell: str, new_text: str) -> str:
    """Same cell (same ref + style), holding new_text. All-digit values are
    written as real numbers so lookups keep working after unmasking; text
    keeps leading zeros / 16+ digits safe as an inline string."""
    open_tag = T_ATTR_RE.sub("", cell[:cell.index(">")]).rstrip().rstrip("/")
    if re.fullmatch(r"0|[1-9]\d{0,14}", new_text):
        return f"{open_tag}><v>{new_text}</v></c>"
    space = ' xml:space="preserve"' if new_text != new_text.strip() else ""
    return f'{open_tag} t="inlineStr"><is><t{space}>{escape(new_text)}</t></is></c>'


def run_pass(xml: str, mode: str, cols,
             shared: list[str], transform) -> tuple[str, int, int]:
    """One pass over a sheet's XML. mode: 'column' (only the target column,
    whole-cell; cols is that column's letters), 'sweep' (everything EXCEPT
    the columns in `cols`, a set), or 'scan' (every cell).
    Returns (new_xml, cells_changed, formula_hits)."""
    changed = 0
    formula_hits = 0

    def repl(m):
        nonlocal changed, formula_hits
        cell = m.group(0)
        open_tag = cell[:cell.find(">")]
        ref = CELL_REF_RE.search(open_tag)
        if not ref:
            return cell
        below_header = int(ref.group(2)) > 1
        if mode == "column" and not (ref.group(1) == cols and below_header):
            return cell
        if mode == "sweep" and ref.group(1) in cols and below_header:
            return cell
        if F_TAG_RE.search(cell):
            # Formulas are NEVER modified — only flag ones that look like
            # they mention an account number or token. Cached numeric results
            # only count when they display as a long whole number (dates,
            # times and prices are floats and never account numbers).
            parts = F_CONTENT_RE.findall(cell)
            for v in V_RE.findall(cell):
                nv = numeric_cell_text(v)
                if nv is not None:
                    parts.append(nv)
                else:
                    try:
                        float(v)          # non-integer numeric: ignore
                    except ValueError:
                        parts.append(v)   # cached string result
            probe = html.unescape(" ".join(parts))
            if TOKEN_RE.search(probe) or ACCOUNT_RE.search(probe):
                formula_hits += 1
            return cell
        tm = re.search(r'\bt="([^"]*)"', open_tag)
        text = cell_text(cell, tm.group(1) if tm else "n", shared)
        if text is None or not text.strip():
            return cell
        result = transform(text, mode == "column")
        if result is None or result == text:
            return cell
        changed += 1
        return rebuild_cell(cell, result)

    return CELL_RE.sub(repl, xml), changed, formula_hits


def _sheet_arcname(target: str) -> str:
    t = target.lstrip("/")
    return t if t.startswith("xl/") else "xl/" + t


def workbook_sheets(zf: zipfile.ZipFile) -> list[tuple[str, str]]:
    """[(display name, archive path), ...] for the workbook's worksheets."""
    wb = zf.read("xl/workbook.xml").decode("utf-8")
    rels_xml = zf.read("xl/_rels/workbook.xml.rels").decode("utf-8")
    rels = {}
    for tag in re.findall(r"<Relationship\b[^>]*>", rels_xml):
        attrs = dict(re.findall(r'([\w:]+)="([^"]*)"', tag))
        if "Id" in attrs and "Target" in attrs:
            rels[attrs["Id"]] = attrs["Target"]
    sheets = []
    for tag in re.findall(r"<sheet\b[^>]*/>", wb):
        attrs = dict(re.findall(r'([\w:]+)="([^"]*)"', tag))
        rid = next((v for k, v in attrs.items() if k == "id" or k.endswith(":id")), None)
        target = rels.get(rid, "")
        if "worksheets/" not in target:
            continue                      # chartsheets etc. hold no cells
        sheets.append((html.unescape(attrs.get("name", "")), _sheet_arcname(target)))
    return sheets


def find_header_column(xml: str, shared: list[str], column: str) -> str | None:
    """Column letters whose row-1 header matches `column`, else None."""
    want = column.strip().lower()
    for m in CELL_RE.finditer(xml):
        cell = m.group(0)
        open_tag = cell[:cell.find(">")]
        ref = CELL_REF_RE.search(open_tag)
        if not ref:
            continue
        if int(ref.group(2)) > 1:
            break                         # cells come in row order
        tm = re.search(r'\bt="([^"]*)"', open_tag)
        text = cell_text(cell, tm.group(1) if tm else "n", shared)
        if text is not None and text.strip().lower() == want:
            return ref.group(1)
    return None


def process_xlsx(path: Path, out: Path, spec: dict, sheet: str | None):
    """spec: {"columns": [(column, transform), ...],   # whole-cell passes
              "sweep": transform | None,               # other cells
              "scan": transform | None}                # every cell (no columns)"""
    global LAST_FORMULA_HITS
    LAST_FORMULA_HITS = 0
    with zipfile.ZipFile(path) as zf:
        names = set(zf.namelist())
        shared = (parse_shared_strings(zf.read("xl/sharedStrings.xml"))
                  if "xl/sharedStrings.xml" in names else [])
        sheets = workbook_sheets(zf)
        if sheet:
            sheets = [s for s in sheets if s[0] == sheet]
            if not sheets:
                sys.exit(f"ERROR: no worksheet named {sheet!r} in {path.name}.")

        docs = {}
        for name, arc in sheets:
            xml = zf.read(arc).decode("utf-8")
            if "<worksheet" not in xml[:4000]:
                sys.exit(f"ERROR: sheet {name!r} uses an XML layout this tool "
                         f"doesn't support — open and re-save the file in Excel first.")
            docs[arc] = xml

        # Resolve each requested column per sheet (header name, else letter).
        # Sheets without that header still get the safety sweep.
        col_map = {arc: [] for arc in docs}      # arc -> [(letters, transform)]
        for column, transform in spec.get("columns", []):
            letter = column.upper() if re.fullmatch(r"[A-Za-z]{1,3}", column) else None
            found = False
            for name, arc in sheets:
                lets = find_header_column(docs[arc], shared, column) or letter
                if lets:
                    col_map[arc].append((lets, transform))
                    found = True
            if not found:
                sys.exit(f"ERROR: no column named {column!r} in any worksheet "
                         f"(and it isn't a column letter).")

        changed = 0

        def do(arc, mode, cols, transform):
            nonlocal changed
            global LAST_FORMULA_HITS
            docs[arc], n, fh = run_pass(docs[arc], mode, cols, shared, transform)
            changed += n
            LAST_FORMULA_HITS += fh

        if spec.get("columns"):
            for arc in docs:
                for lets, transform in col_map[arc]:
                    do(arc, "column", lets, transform)
            if spec.get("sweep"):
                for arc in docs:
                    do(arc, "sweep", {lets for lets, _ in col_map[arc]}, spec["sweep"])
        elif spec.get("scan"):
            for arc in docs:
                do(arc, "scan", None, spec["scan"])

        # Rebuild the zip: swap in the edited sheets, copy everything else
        # through untouched (styles, tables, calc chain, external links...).
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
            for info in zf.infolist():
                data = (docs[info.filename].encode("utf-8")
                        if info.filename in docs else zf.read(info.filename))
                zi = zipfile.ZipInfo(info.filename, date_time=info.date_time)
                zi.compress_type = info.compress_type
                zi.external_attr = info.external_attr
                zout.writestr(zi, data)
    return changed


# ------------------------------------------------------------- file I/O

def process_csv(path: Path, out: Path, spec: dict):
    with open(path, newline="") as f:
        rows = list(csv.reader(f))
    header = [h.strip().lower() for h in rows[0]] if rows else []
    col_jobs = []                                  # [(index, transform)]
    for column, transform in spec.get("columns", []):
        if column.strip().lower() in header:
            col_jobs.append((header.index(column.strip().lower()), transform))
        else:
            sys.exit(f"ERROR: no column named {column!r} in {path.name}.")
    col_idxs = {c for c, _ in col_jobs}
    changed = 0

    def apply(r, c, transform, whole):
        nonlocal changed
        val = rows[r][c]
        if not val:
            return
        result = transform(val, whole)
        if result is not None:
            rows[r][c] = result
            changed += 1

    for c, transform in col_jobs:
        for r in range(1, len(rows)):
            if c < len(rows[r]):
                apply(r, c, transform, True)
    other = spec.get("sweep") if col_jobs else spec.get("scan")
    if other:
        for r, row in enumerate(rows):
            for c in range(len(row)):
                if c in col_idxs and r > 0:
                    continue
                apply(r, c, other, False)
    with open(out, "w", newline="") as f:
        csv.writer(f).writerows(rows)
    return changed


def mask_spec(masker: "Masker", column: str | None,
              names_column: str | None = None) -> dict:
    masker.sweep_names = bool(names_column)
    masker._sweep_re = None
    cols = []
    if column:
        cols.append((column, masker.mask_text))
    if names_column:
        cols.append((names_column, masker.mask_name))
    if cols:
        return {"columns": cols, "sweep": masker.sweep_text}
    return {"scan": masker.mask_text}


def unmask_spec(um: "Unmasker") -> dict:
    return {"scan": lambda text, _whole: um.unmask_text(text)}


def process_file(path: Path, out: Path, spec: dict, sheet=None):
    """Process path -> out. When out is the same file, write to a hidden temp
    file first and atomically swap it in, so a crash can't corrupt the file."""
    target = out
    tmp = None
    if out.resolve() == path.resolve():
        tmp = out.with_name("." + out.name + ".masktmp")
        target = tmp
    try:
        if path.suffix.lower() == ".csv":
            changed = process_csv(path, target, spec)
        elif path.suffix.lower() in (".xlsx", ".xlsm"):
            changed = process_xlsx(path, target, spec, sheet)
        else:
            sys.exit(f"ERROR: unsupported file type {path.suffix!r} (use .xlsx or .csv).")
    except BaseException:
        if tmp is not None and tmp.exists():
            tmp.unlink()
        raise
    return changed, tmp


def run_file(args, spec):
    path = Path(args.file)
    if not path.exists():
        sys.exit(f"ERROR: {path} not found.")
    if getattr(args, "in_place", False):
        out = path
    elif args.output:
        out = Path(args.output)
    else:
        suffix = "_masked" if args.cmd == "mask" else "_unmasked"
        out = path.with_stem(path.stem + suffix)
    if out.resolve() == Path(args.vault).resolve():
        sys.exit("ERROR: output path collides with the vault file.")
    changed, tmp = process_file(path, out, spec, args.sheet)
    return out, changed, tmp


# ----------------------------------------------------------------- main

def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    for name, help_ in (("mask", "replace real account numbers with tokens"),
                        ("unmask", "restore real account numbers from tokens")):
        s = sub.add_parser(name, help=help_)
        s.add_argument("file", help="input .xlsx or .csv")
        s.add_argument("-i", "--in-place", action="store_true",
                       help="update the file itself instead of writing a copy")
        s.add_argument("-o", "--output", help="output path (default: adds _masked/_unmasked)")
        s.add_argument("--column", help="only touch this column (header name or letter); "
                                        "masks every value in it, header row excluded")
        s.add_argument("--names-column", help="also mask this column of client names "
                                              "with NAME- tokens (mask only)")
        s.add_argument("--sheet", help="only touch this worksheet (xlsx only)")
        s.add_argument("--vault", default=str(DEFAULT_VAULT),
                       help=f"vault file (default: {DEFAULT_VAULT})")

    s = sub.add_parser("check", help="read-only scan: is this file safe to upload?")
    s.add_argument("file", help="input .xlsx or .csv")
    s.add_argument("--sheet", help="only check this worksheet (xlsx only)")
    s.add_argument("--vault", default=str(DEFAULT_VAULT))

    s = sub.add_parser("list", help="show how many mappings the vault holds")

    s.add_argument("--vault", default=str(DEFAULT_VAULT))

    s = sub.add_parser("restore-vault",
                       help="bring back the newest vault backup from "
                            f"{BACKUP_DIR}")
    s.add_argument("--vault", default=str(DEFAULT_VAULT))

    args = p.parse_args()
    vault_path = Path(args.vault)

    if args.cmd == "restore-vault":
        used = restore_latest_backup(vault_path)
        vault = load_vault(vault_path)
        print(f"Restored {vault_path}")
        print(f"  from backup: {used.name}  ({len(vault['map'])} mappings)")
        return

    vault = load_vault(vault_path)
    backup_vault(vault_path)   # opportunistic: no-op unless something changed

    if args.cmd == "list":
        backups = vault_backups(vault_path)
        print(f"Vault: {vault_path}")
        print(f"Mappings: {len(vault['map'])}")
        if vault["map"]:
            print(f"Created: {vault.get('created', '?')}   "
                  f"Updated: {vault.get('updated', '?')}")
        if backups:
            print(f"Backups: {len(backups)} in {BACKUP_DIR}  "
                  f"(newest: {backups[-1].name})")
        else:
            print(f"Backups: none yet — one is written automatically on every mask.")
        return

    if args.cmd == "check":
        ck = check_file(Path(args.file), vault, args.sheet)
        print(f"Checked {args.file}")
        print(f"  Vault account numbers visible: {ck.reals}")
        print(f"  Vault client names visible:    {ck.names}")
        print(f"  Other account-like numbers:    {ck.acct_like}")
        print(f"  Masked tokens present:         {ck.tokens}")
        if ck.formula_hits:
            print(f"  Formula cells mentioning account-like numbers: {ck.formula_hits}")
        if ck.reals:
            print("  ❌ NOT SAFE — real account numbers are still visible. "
                  "Mask the file first.")
            sys.exit(2)
        if ck.names:
            print("  ⚠️ No account numbers visible, but vault client names are — "
                  "mask with a names column if they shouldn't go out.")
            return
        print("  ✅ No vault values visible."
              + (" Review the account-like numbers above." if ck.acct_like else ""))
        return

    if args.cmd == "mask":
        masker = Masker(vault, column_mode=bool(args.column or args.names_column))
        out, changed, tmp = run_file(args, mask_spec(masker, args.column, args.names_column))
        # Vault first: never overwrite real numbers before the mapping is safe.
        save_vault(vault_path, vault)
        if tmp is not None:
            tmp.replace(out)
        where = f"{out} (updated in place)" if getattr(args, "in_place", False) else out
        print(f"Masked {changed} cell(s) -> {where}")
        print(f"  {masker.new} new token(s), {masker.reused} reused from vault")
        if masker.swept:
            print(f"  Safety sweep: also replaced {masker.swept} leaked occurrence(s) "
                  f"outside the {args.column!r} column")
        if LAST_FORMULA_HITS:
            print(f"  NOTE: {LAST_FORMULA_HITS} formula cell(s) may mention account-like "
                  f"numbers — formulas are never modified, review before uploading.")
        print(f"  Vault: {vault_path}  ({len(vault['map'])} total mappings)")
        print("  KEEP THE VAULT FILE PRIVATE — it maps tokens back to real numbers.")

    elif args.cmd == "unmask":
        if not vault["map"]:
            sys.exit(f"ERROR: vault {vault_path} is empty — nothing to unmask with.")
        um = Unmasker(vault)
        out, changed, tmp = run_file(args, unmask_spec(um))
        if tmp is not None:
            tmp.replace(out)
        where = f"{out} (updated in place)" if getattr(args, "in_place", False) else out
        print(f"Restored {um.restored} token(s) in {changed} cell(s) -> {where}")
        if um.unknown:
            print(f"  WARNING: {len(um.unknown)} token(s) not found in this vault, "
                  f"left as-is: {', '.join(sorted(um.unknown)[:10])}")


if __name__ == "__main__":
    main()
