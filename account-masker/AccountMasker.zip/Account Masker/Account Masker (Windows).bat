@echo off
title Account Masker
cd /d "%~dp0"
set "PATH=%USERPROFILE%\.local\bin;%PATH%"

where uv >nul 2>nul
if not errorlevel 1 goto run

echo.
echo Account Masker needs a small free helper called "uv" (one-time setup).
echo It will be downloaded from astral.sh, the official source.
echo.
choice /c YN /m "Install it now"
if errorlevel 2 exit /b
powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://astral.sh/uv/install.ps1 | iex"
where uv >nul 2>nul
if errorlevel 1 (
    echo.
    echo Setup finished but uv was not found. Close this window,
    echo then double-click Account Masker again.
    pause
    exit /b
)

:run
echo Starting Account Masker... (the very first run can take a minute)
uv run --managed-python --python 3.13 account_masker_gui.py
if errorlevel 1 (
    echo.
    echo Something went wrong starting Account Masker.
    pause
)
