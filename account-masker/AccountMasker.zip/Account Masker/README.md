# Account Masker

Replaces real account numbers with fake tokens (`ACCT-7F3K92` style) before a
file goes into an unsecured system, and restores the real numbers when it
comes back out. Runs entirely on your machine — nothing is sent anywhere.

## Easiest way: the app

**Mac:** double-click **Account Masker.app** in this folder (drag it to your
Dock to keep it one click away).
**Windows:** double-click **Account Masker (Windows).bat** — it offers to
install the `uv` helper on first run, then opens the app.

A window opens with two buttons:

- **Mask a file…** — pick your Excel/CSV file, confirm which column holds the
  account numbers (it guesses automatically), and the file itself is updated
  with fake tokens — ready to upload, no extra copies.
- **Unmask a file…** — pick the same file after you take it back out; the
  real numbers are put back into it.

Because the file is changed in place, the ONLY record of the real numbers
while a file is masked is the vault (see below) — one more reason to keep it
backed up.

The first launch takes a few extra seconds while it sets itself up; after
that it opens instantly.

## Requirements

- `uv` (already installed via Homebrew). It auto-installs everything else on
  first run — no other setup.

## Terminal usage (optional)

Everything runs from Terminal in this folder (`~/Desktop/Account\ Masker`).

**Mask a sheet before uploading it (updates the file itself):**

```bash
uv run account_masker.py mask accounts.xlsx -i --column "Account Number"
```

**Restore the real numbers after you take it back out:**

```bash
uv run account_masker.py unmask accounts.xlsx -i
```

Drop the `-i` if you'd rather keep the original untouched and write a
separate `_masked` / `_unmasked` copy instead.

**See how many numbers are stored in the vault:**

```bash
uv run account_masker.py list
```

## Options

| Flag | What it does |
|---|---|
| `--column "Account Number"` | Mask every value in that column (header name or letter like `B`). Recommended — precise, no guessing. |
| *(no `--column`)* | Scan the whole sheet and mask anything that looks like an account number (6+ digits, dashes/spaces allowed). Convenient, but can catch phone numbers etc. |
| `--sheet "Sheet1"` | Only touch one worksheet (xlsx only). |
| `-o output.xlsx` | Choose the output filename. |
| `--vault path.json` | Use a different vault file (e.g. one vault per client). |

Works on `.xlsx` and `.csv` files.

## How it works

- Excel files are edited **surgically**: only the individual cells being
  masked or unmasked are rewritten. Formulas, tables, defined names, links
  to other workbooks, charts and formatting are carried through untouched,
  so the workbook still works in Excel after the round trip.
- Unmasking puts plain account numbers back as **real numbers** (not text),
  so lookups like `MATCH`/`VLOOKUP` against them keep working. Values with
  leading zeros stay text, exactly as they were.
- Formulas are never modified. If a formula looks like it mentions an
  account number, the tool tells you so you can review before uploading.
- Each real number gets a random token. The **same number always gets the same
  token**, across files and across runs, so masked data stays consistent.
- The real↔fake mapping is stored in `account_vault.json` in this folder.
- In `--column` mode, a safety sweep also replaces any of those account
  numbers that leak into *other* cells (e.g. repeated in a notes column).
- Unmasking finds tokens anywhere in the sheet — even mid-sentence — and swaps
  the real numbers back. Tokens missing from the vault are reported and left
  as-is.

## ⚠️ Protect the vault

`account_vault.json` maps every fake token back to the real account number.

- **Never** upload it, email it, or put it in the unsecured system.
- **Back it up** somewhere safe (e.g. an encrypted disk or password manager
  attachment). If it's lost, masked files can never be reverted.
- Anyone with access to this computer can read it — it is stored unencrypted
  by your choice. If that ever becomes a concern, ask for the encrypted-vault
  upgrade.
