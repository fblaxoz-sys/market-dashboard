#!/usr/bin/env -S uv run --managed-python --python 3.13 --script
# /// script
# requires-python = ">=3.13"
# dependencies = ["openpyxl>=3.1"]
# ///
"""
Account Masker — point-and-click window around account_masker.py.

Launch:  uv run --managed-python --python 3.13 account_masker_gui.py
(or double-click "Account Masker.app" in this folder)
"""

import os
import subprocess
import sys
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

sys.path.insert(0, str(Path(__file__).resolve().parent))
import account_masker as am

FILETYPES = [("Excel or CSV", "*.xlsx *.xlsm *.csv"),
             ("Excel", "*.xlsx *.xlsm"), ("CSV", "*.csv")]
SCAN_LABEL = "(Scan entire sheet for account-like numbers)"


def read_headers(path: Path) -> list[str]:
    """First-row values, for the column dropdown."""
    if path.suffix.lower() == ".csv":
        import csv
        with open(path, newline="") as f:
            row = next(csv.reader(f), [])
        return [h for h in row if h.strip()]
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True)
    ws = wb.worksheets[0]
    row = next(ws.iter_rows(min_row=1, max_row=1, values_only=True), ())
    wb.close()
    return [str(h) for h in row if h is not None and str(h).strip()]


def guess_account_header(headers: list[str]) -> str | None:
    for h in headers:
        if "account" in h.lower() or "acct" in h.lower():
            return h
    return None


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        root.title("Account Masker")
        root.geometry("560x460")
        root.minsize(480, 380)

        outer = ttk.Frame(root, padding=16)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text="Account Masker",
                  font=("Helvetica", 20, "bold")).pack(anchor="w")
        ttk.Label(outer, foreground="gray",
                  text="Mask before uploading to an unsecured system. "
                       "Unmask after you take the file back out.").pack(anchor="w", pady=(0, 12))

        btns = ttk.Frame(outer)
        btns.pack(fill="x", pady=(0, 12))
        mask_btn = tk.Button(btns, text="Mask a file…", font=("Helvetica", 14),
                             height=2, command=self.do_mask)
        unmask_btn = tk.Button(btns, text="Unmask a file…", font=("Helvetica", 14),
                               height=2, command=self.do_unmask)
        mask_btn.pack(side="left", expand=True, fill="x", padx=(0, 6))
        unmask_btn.pack(side="left", expand=True, fill="x", padx=(6, 0))

        self.log = tk.Text(outer, height=10, wrap="word", state="disabled",
                           relief="solid", borderwidth=1, padx=8, pady=8)
        self.log.pack(fill="both", expand=True)

        self.status = ttk.Label(outer, foreground="gray")
        self.status.pack(anchor="w", pady=(8, 0))
        self.refresh_status()
        self.say("Ready. Pick a file to mask or unmask — the file itself is "
                 "updated, so there's just one copy to keep track of.")

    # ------------------------------------------------------------- helpers

    def say(self, text: str):
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def refresh_status(self):
        try:
            vault = am.load_vault(am.DEFAULT_VAULT)
            n = len(vault["map"])
        except SystemExit:
            n = "?"
        self.status.configure(
            text=f"Vault: {am.DEFAULT_VAULT.name} — {n} account number(s) stored. "
                 f"Keep this file private and backed up.")

    def pick_file(self, title: str) -> Path | None:
        p = filedialog.askopenfilename(title=title, filetypes=FILETYPES)
        return Path(p) if p else None

    def ask_column(self, headers: list[str]) -> str | None | bool:
        """Returns header name, None for scan mode, or False if cancelled."""
        dlg = tk.Toplevel(self.root)
        dlg.title("Which column holds the account numbers?")
        dlg.transient(self.root)
        dlg.grab_set()
        frame = ttk.Frame(dlg, padding=16)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="Which column holds the account numbers?").pack(anchor="w")

        options = headers + [SCAN_LABEL]
        guess = guess_account_header(headers)
        var = tk.StringVar(value=guess if guess else (headers[0] if headers else SCAN_LABEL))
        combo = ttk.Combobox(frame, textvariable=var, values=options,
                             state="readonly", width=42)
        combo.pack(pady=10)

        result: list = [False]

        def ok():
            result[0] = None if var.get() == SCAN_LABEL else var.get()
            dlg.destroy()

        row = ttk.Frame(frame)
        row.pack()
        ttk.Button(row, text="Cancel", command=dlg.destroy).pack(side="left", padx=6)
        ttk.Button(row, text="Mask it", command=ok).pack(side="left", padx=6)
        dlg.wait_window()
        return result[0]

    def process_in_place(self, path: Path, transform, column):
        """Rewrite the file itself (via am's atomic temp-swap). Caller is
        responsible for saving the vault BEFORE calling finish()."""
        changed, tmp = am.process_file(path, path, transform, column)
        return changed, tmp

    def reveal(self, path: Path):
        """Show the finished file in Finder / File Explorer."""
        try:
            if sys.platform == "darwin":
                subprocess.run(["open", "-R", str(path)])
            elif sys.platform == "win32":
                subprocess.run(["explorer", f"/select,{path}"])
            else:
                subprocess.run(["xdg-open", str(path.parent)])
        except Exception:
            pass  # revealing is a courtesy; never let it break the run

    # ------------------------------------------------------------- actions

    def do_mask(self):
        path = self.pick_file("Choose the file to MASK")
        if not path:
            return
        try:
            headers = read_headers(path)
        except Exception as e:
            messagebox.showerror("Account Masker", f"Couldn't read {path.name}:\n{e}")
            return
        column = self.ask_column(headers) if headers else None
        if column is False:
            return
        try:
            vault = am.load_vault(am.DEFAULT_VAULT)
            masker = am.Masker(vault, column_mode=column is not None)
            changed, tmp = self.process_in_place(path, masker.mask_text, column)
            # Vault first: never overwrite real numbers before the mapping is safe.
            am.save_vault(am.DEFAULT_VAULT, vault)
            if tmp is not None:
                tmp.replace(path)
        except SystemExit as e:
            messagebox.showerror("Account Masker", str(e))
            return
        except Exception as e:
            messagebox.showerror("Account Masker", f"Something went wrong:\n{e}")
            return
        msg = (f"MASKED {path.name} — updated in place\n"
               f"   • {changed} cell(s) masked "
               f"({masker.new} new, {masker.reused} seen before)")
        if masker.swept:
            msg += (f"\n   • safety sweep caught {masker.swept} extra "
                    f"occurrence(s) outside the chosen column")
        msg += ("\n   ✅ This same file is now safe to upload. Unmask it here "
                "when you take it back out.")
        self.say(msg)
        self.refresh_status()
        self.reveal(path)

    def do_unmask(self):
        path = self.pick_file("Choose the file to UNMASK")
        if not path:
            return
        try:
            vault = am.load_vault(am.DEFAULT_VAULT)
            if not vault["map"]:
                messagebox.showerror("Account Masker",
                                     "The vault is empty — mask something first.")
                return
            um = am.Unmasker(vault)
            transform = lambda text, _whole: um.unmask_text(text)
            changed, tmp = self.process_in_place(path, transform, None)
            if tmp is not None:
                tmp.replace(path)
        except SystemExit as e:
            messagebox.showerror("Account Masker", str(e))
            return
        except Exception as e:
            messagebox.showerror("Account Masker", f"Something went wrong:\n{e}")
            return
        msg = (f"UNMASKED {path.name} — updated in place\n"
               f"   • {um.restored} token(s) restored to real account numbers")
        if um.unknown:
            msg += (f"\n   ⚠️ {len(um.unknown)} token(s) not in the vault were left "
                    f"as-is: {', '.join(sorted(um.unknown)[:8])}")
        self.say(msg)
        self.reveal(path)


def main():
    root = tk.Tk()
    App(root)
    if os.environ.get("ACCOUNT_MASKER_SELFTEST"):
        root.after(1500, root.destroy)
    root.lift()
    root.attributes("-topmost", True)
    root.after(400, lambda: root.attributes("-topmost", False))
    root.mainloop()


if __name__ == "__main__":
    main()
